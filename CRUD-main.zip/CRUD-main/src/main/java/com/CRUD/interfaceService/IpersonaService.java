package com.CRUD.interfaceService;

import java.util.List;
//import java.util.Opcional;
import java.util.Optional;

import com.CRUD.modelo.Persona;

public interface IpersonaService {
	

	public Optional<Persona> buscarId(int id);
	public List <Persona> listar();
	public Optional <Persona>ListarId(int id);
	public int save (Persona p);
	public void delete (int id);
	
	
}
