function eliminar(id){
	swal({
  title: "¿Estás seguro de eliminar este registro?",
  text: "una vez eliminado no podrá recuperarlo",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((OK) => {
  if (OK) {
	$.ajax({
		url:"/eliminar/"+id,
		success: function (res){
			console.log(res);
		}
	});
    swal("El archivo se ha eliminado con exito", {
      icon: "success",
    }).then((ok)=>{
		if(ok){
			location.href="/listar";
		}
});
  } else {
    swal("El archivo NO se ha eliminado");
  }
});
} 